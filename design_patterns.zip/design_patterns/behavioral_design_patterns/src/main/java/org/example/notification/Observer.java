
package org.example.notification;

public interface Observer {
    void update(String message);
}
