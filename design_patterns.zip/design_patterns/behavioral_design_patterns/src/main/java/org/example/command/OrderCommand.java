
package org.example.command;

public interface OrderCommand {
    void execute();
}
