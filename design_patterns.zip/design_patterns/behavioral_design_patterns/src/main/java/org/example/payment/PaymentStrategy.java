
package org.example.payment;

public interface PaymentStrategy {
    void pay(double amount);
}
