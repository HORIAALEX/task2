package org.example.creational;

public class CarConfiguration {

    public static void main(String[] args) {
        // TODO: Create and configure different cars using the Builder pattern

//        Car car1 = new Car....
//        System.out.println(car1);
    }
}
