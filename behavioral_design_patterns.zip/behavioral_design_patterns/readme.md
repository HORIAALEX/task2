# Behavioral Design Patterns (Plain Java)

Minimal console-based demo of behavioral design patterns in Java.

## Patterns Demonstrated
- Chain of Responsibility: order validation handlers.
- Command: place and cancel order commands executed by an invoker.
- Observer: email and SMS observers notified on order status changes.
- Strategy: payment strategies selected by payment method.

## Run

From the repository root:

```bash
mvn -pl design_patterns/behavioral_design_patterns -q package
java -cp design_patterns/behavioral_design_patterns/target/classes org.example.behavioral.Main
```
