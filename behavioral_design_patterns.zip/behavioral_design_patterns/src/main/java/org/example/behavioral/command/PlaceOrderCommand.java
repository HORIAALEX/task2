package org.example.behavioral.command;

import org.example.behavioral.model.Order;
import org.example.behavioral.model.OrderStatus;
import org.example.behavioral.observer.NotificationService;
import org.example.behavioral.strategy.PaymentStrategy;

public class PlaceOrderCommand implements Command {
    private final Order order;
    private final PaymentStrategy paymentStrategy;
    private final NotificationService notificationService;

    public PlaceOrderCommand(Order order, PaymentStrategy paymentStrategy, NotificationService notificationService) {
        this.order = order;
        this.paymentStrategy = paymentStrategy;
        this.notificationService = notificationService;
    }

    @Override
    public void execute() {
        paymentStrategy.pay(order.getTotalAmount());
        order.setStatus(OrderStatus.PAID);
        notificationService.notifyStatusChange(order);
    }
}
