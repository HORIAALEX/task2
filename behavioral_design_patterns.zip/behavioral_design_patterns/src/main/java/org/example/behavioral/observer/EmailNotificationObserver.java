package org.example.behavioral.observer;

import org.example.behavioral.model.Order;

public class EmailNotificationObserver implements OrderObserver {
    @Override
    public void onStatusChanged(Order order) {
        System.out.println("EMAIL: Order " + order.getId() + " status is now " + order.getStatus());
    }
}
