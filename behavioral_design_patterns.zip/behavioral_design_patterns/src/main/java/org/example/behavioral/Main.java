package org.example.behavioral;

import org.example.behavioral.chain.InventoryCheckHandler;
import org.example.behavioral.chain.OrderValidationHandler;
import org.example.behavioral.chain.PaymentValidationHandler;
import org.example.behavioral.chain.ValidationException;
import org.example.behavioral.command.CancelOrderCommand;
import org.example.behavioral.command.CommandInvoker;
import org.example.behavioral.command.PlaceOrderCommand;
import org.example.behavioral.model.Order;
import org.example.behavioral.model.OrderStatus;
import org.example.behavioral.model.PaymentMethod;
import org.example.behavioral.observer.EmailNotificationObserver;
import org.example.behavioral.observer.NotificationService;
import org.example.behavioral.observer.SmsNotificationObserver;
import org.example.behavioral.strategy.PaymentStrategy;
import org.example.behavioral.strategy.PaymentStrategyFactory;

public class Main {
    public static void main(String[] args) {
        Order order = new Order(1L, "Ada Lovelace", 250.00, PaymentMethod.CREDIT_CARD);
        Order largeOrder = new Order(2L, "Grace Hopper", 1500.00, PaymentMethod.PAYPAL);

        OrderValidationHandler inventoryHandler = new InventoryCheckHandler();
        OrderValidationHandler paymentHandler = new PaymentValidationHandler();
        inventoryHandler.setNext(paymentHandler);

        NotificationService notificationService = new NotificationService();
        notificationService.addObserver(new EmailNotificationObserver());
        notificationService.addObserver(new SmsNotificationObserver());

        PaymentStrategyFactory strategyFactory = new PaymentStrategyFactory();
        CommandInvoker invoker = new CommandInvoker();

        processOrder(order, inventoryHandler, strategyFactory, notificationService, invoker);
        processOrder(largeOrder, inventoryHandler, strategyFactory, notificationService, invoker);
    }

    private static void processOrder(
            Order order,
            OrderValidationHandler validationChain,
            PaymentStrategyFactory strategyFactory,
            NotificationService notificationService,
            CommandInvoker invoker
    ) {
        try {
            validationChain.handle(order);
            order.setStatus(OrderStatus.VALIDATED);
            notificationService.notifyStatusChange(order);

            PaymentStrategy strategy = strategyFactory.getStrategy(order.getPaymentMethod());
            invoker.run(new PlaceOrderCommand(order, strategy, notificationService));
        } catch (ValidationException ex) {
            order.setStatus(OrderStatus.REJECTED);
            notificationService.notifyStatusChange(order);
            System.out.println("Order " + order.getId() + " rejected: " + ex.getMessage());
        }

        invoker.run(new CancelOrderCommand(order, notificationService));
    }
}
