package org.example.behavioral.model;

public enum OrderStatus {
    NEW,
    VALIDATED,
    PAID,
    CANCELED,
    REJECTED
}
