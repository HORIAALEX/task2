package org.example.behavioral.observer;

import org.example.behavioral.model.Order;

public class SmsNotificationObserver implements OrderObserver {
    @Override
    public void onStatusChanged(Order order) {
        System.out.println("SMS: Order " + order.getId() + " status is now " + order.getStatus());
    }
}
