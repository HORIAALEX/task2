package org.example.behavioral.chain;

public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}
