package org.example.behavioral.strategy;

import java.util.EnumMap;
import java.util.Map;
import org.example.behavioral.model.PaymentMethod;

public class PaymentStrategyFactory {
    private final Map<PaymentMethod, PaymentStrategy> strategies = new EnumMap<>(PaymentMethod.class);

    public PaymentStrategyFactory() {
        strategies.put(PaymentMethod.CREDIT_CARD, new CreditCardPaymentStrategy());
        strategies.put(PaymentMethod.PAYPAL, new PaypalPaymentStrategy());
    }

    public PaymentStrategy getStrategy(PaymentMethod method) {
        PaymentStrategy strategy = strategies.get(method);
        if (strategy == null) {
            throw new IllegalArgumentException("Unsupported payment method: " + method);
        }
        return strategy;
    }
}
