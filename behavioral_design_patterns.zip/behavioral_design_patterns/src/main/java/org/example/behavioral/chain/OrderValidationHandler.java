package org.example.behavioral.chain;

import org.example.behavioral.model.Order;

public abstract class OrderValidationHandler {
    private OrderValidationHandler next;

    public void setNext(OrderValidationHandler next) {
        this.next = next;
    }

    public void handle(Order order) {
        if (!doValidate(order)) {
            throw new ValidationException(failureMessage(order));
        }
        if (next != null) {
            next.handle(order);
        }
    }

    protected abstract boolean doValidate(Order order);

    protected abstract String failureMessage(Order order);
}
