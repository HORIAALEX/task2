package org.example.behavioral.command;

import org.example.behavioral.model.Order;
import org.example.behavioral.model.OrderStatus;
import org.example.behavioral.observer.NotificationService;

public class CancelOrderCommand implements Command {
    private final Order order;
    private final NotificationService notificationService;

    public CancelOrderCommand(Order order, NotificationService notificationService) {
        this.order = order;
        this.notificationService = notificationService;
    }

    @Override
    public void execute() {
        order.setStatus(OrderStatus.CANCELED);
        notificationService.notifyStatusChange(order);
    }
}
