package org.example.behavioral.observer;

import java.util.ArrayList;
import java.util.List;
import org.example.behavioral.model.Order;

public class NotificationService {
    private final List<OrderObserver> observers = new ArrayList<>();

    public void addObserver(OrderObserver observer) {
        observers.add(observer);
    }

    public void notifyStatusChange(Order order) {
        for (OrderObserver observer : observers) {
            observer.onStatusChanged(order);
        }
    }
}
