package org.example.behavioral.model;

public class Order {
    private final long id;
    private final String customerName;
    private final double totalAmount;
    private final PaymentMethod paymentMethod;
    private OrderStatus status;

    public Order(long id, String customerName, double totalAmount, PaymentMethod paymentMethod) {
        this.id = id;
        this.customerName = customerName;
        this.totalAmount = totalAmount;
        this.paymentMethod = paymentMethod;
        this.status = OrderStatus.NEW;
    }

    public long getId() {
        return id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}
