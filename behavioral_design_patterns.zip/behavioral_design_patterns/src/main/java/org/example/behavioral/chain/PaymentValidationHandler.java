package org.example.behavioral.chain;

import org.example.behavioral.model.Order;

public class PaymentValidationHandler extends OrderValidationHandler {
    @Override
    protected boolean doValidate(Order order) {
        return order.getPaymentMethod() != null;
    }

    @Override
    protected String failureMessage(Order order) {
        return "Payment method is required.";
    }
}
