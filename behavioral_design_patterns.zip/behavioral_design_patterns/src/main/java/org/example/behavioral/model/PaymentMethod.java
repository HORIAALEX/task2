package org.example.behavioral.model;

public enum PaymentMethod {
    CREDIT_CARD,
    PAYPAL
}
