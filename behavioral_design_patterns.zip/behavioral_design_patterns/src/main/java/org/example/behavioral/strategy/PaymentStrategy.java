package org.example.behavioral.strategy;

public interface PaymentStrategy {
    void pay(double amount);
}
