package org.example.behavioral.chain;

import org.example.behavioral.model.Order;

public class InventoryCheckHandler extends OrderValidationHandler {
    private static final double INVENTORY_LIMIT = 1000.0;

    @Override
    protected boolean doValidate(Order order) {
        return order.getTotalAmount() <= INVENTORY_LIMIT;
    }

    @Override
    protected String failureMessage(Order order) {
        return "Insufficient inventory for amount: " + order.getTotalAmount();
    }
}
