package org.example.behavioral.command;

public interface Command {
    void execute();
}
