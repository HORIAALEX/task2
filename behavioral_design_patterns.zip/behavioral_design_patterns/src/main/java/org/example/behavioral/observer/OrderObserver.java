package org.example.behavioral.observer;

import org.example.behavioral.model.Order;

public interface OrderObserver {
    void onStatusChanged(Order order);
}
